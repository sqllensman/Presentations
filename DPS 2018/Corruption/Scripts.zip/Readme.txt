Running Scripts requires:

A SQL Server 2016 SP1 Version
A Copy of the CheckDB Database (Backup attached)
A copy of the Broken Db (Backup enclosed)

Will also require a copy of:
AdventureWorks2014
AdventureWorksDW2014
Files from Corruption Challenge (links in Scripts)