﻿# Tail of Log Backup of Damaged File

Remove-Item -Path "C:\SQLSaturday\DBFiles\Data\CorruptionChallenge3.mdf" -Force

Copy-Item "C:\SQLSaturday\DBFiles\Backup\CC\CC_3\CorruptionChallenge3_log.ldf" "C:\SQLSaturday\DBFiles\Log" -Force

