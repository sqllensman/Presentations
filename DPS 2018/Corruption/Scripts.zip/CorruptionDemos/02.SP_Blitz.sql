-- BrentOzar
-- Download from https://www.brentozar.com/first-aid/
Exec sp_Blitz