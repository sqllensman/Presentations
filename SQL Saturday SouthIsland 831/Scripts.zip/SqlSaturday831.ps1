﻿CLS
Return 'This is a demo, don''t run the whole thing, fool!!'

cls
Remove-Module -Name dbatools
# Load local copy
Import-Module "C:\GitHub\dbatools\dbatools.psm1" -Force

## Main Site
Start-Process "https://dbatools.io/"


# Installation
Start-Process 'https://dbatools.io/soup2nutz/'

# Execution Policy
Get-ExecutionPolicy 
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Powershell Repository
Get-PSRepository 
Set-PSRepository -Name PSGallery -InstallationPolicy Trusted

# Set ip a Logal Repository
Start-Process 'https://powershellexplained.com/2017-05-30-Powershell-your-first-PSScript-repository/?utm_source=blog&utm_medium=blog&utm_content=nuget' 

# Install Module
Install-Module dbatools 


## Lets look at the commands
$cmds = Get-Command -Module dbatools -CommandType Function 
$cmds | Out-GridView
$cmds.Count

Start-Process 'https://sqlbits.com/Sessions/Event17/Simplifying_XEvents_Management_with_dbatools'

## How do we find commands?
Find-DbaCommand -Tag Backup
Find-DbaCommand -Tag Restore
Find-DbaCommand -Tag Migration
Find-DbaCommand -Tag Agent
Find-DbaCommand -Tag DBCC
Find-DbaCommand -Pattern User 
Find-DbaCommand -Pattern Config
Find-DbaCommand -Pattern Error

Find-DbaCommand -Author Patrick Flynn | Out-GridView

Start-Process 'https://dbatools.io/commands/'


## How do we use commands?

## ALWAYS ALWAYS use Get-Help

Get-Help Test-DbaLinkedServerConnection -Full
Get-Help Test-DbaLinkedServerConnection -ShowWindow

Find-DbaCommand -Pattern Index | Out-GridView -PassThru | Get-Help -ShowWindow 

# Documentations
Start-Process 'https://docs.dbatools.io/'

## Lets look at how easy it is to get information about one or many sql server instances from the command line with one line of code


## Server Level
Get-DbaService -ComputerName LensmanSB | Out-GridView 

Get-DbaDiskSpace -ComputerName LensmanSB  | Out-GridView
Get-DbaComputerSystem -ComputerName LensmanSB  | Out-GridView
Get-DbaOperatingSystem -ComputerName LensmanSB  | Out-GridView

## SHow me the filegroups in a database 
Get-DbaDbFileGroup -SqlInstance lensmansb -Database WideWorldImporters | Out-GridView

## SHow me the views in a database 
Get-DbaDbView -SqlInstance lensmansb -Database WideWorldImporters -ExcludeSystemView | Out-GridView

## Show Me UDFs in database or on an instance
Get-DbaDbUdf -SqlInstance lensmansb -Database WideWorldImporters -ExcludeSystemUdf | Out-GridView

## Show me Database Partition functions
Get-DbaDbPartitionFunction -SqlInstance lensmansb -Database WideWorldImporters | Out-GridView 

# more detail
Get-DbaDbPartitionFunction -SqlInstance lensmansb -Database WideWorldImporters | Select * | Out-GridView 

## Show Database Partition Schemes
Get-DbaDbPartitionScheme -SqlInstance lensmansb -Database WideWorldImporters 

# more detail
Get-DbaDbPartitionScheme -SqlInstance bolton -SqlCredential $cred -Database WideWorldImporters | Select *



## What are my default paths ?

# C
$cred = Get-Credential -UserName sqladmin -Message Password:dbatools.IO 

$cred | Export-CliXml -Path "C:\SQLSaturday\DemoCred.Cred"
$cred = $null
# Retrieve Credential 
$cred = Import-CliXml -Path "C:\SQLSaturday\DemoCred.Cred"
Get-DbaDefaultPath -SqlInstance lensmansb:14331, lensmansb:14332 -SqlCredential $cred 

## Where are my Error logs?
Get-DbaErrorLogConfig -SqlInstance lensmansb 
# Linux
Get-DbaErrorLogConfig -SqlInstance lensmansb:14331, lensmansb:14332 -SqlCredential $cred 



# First, backup the databases because backup/restore t-sql is what's exported
Backup-DbaDatabase -SqlInstance localhost:14331 -SqlCredential $cred -BackupDirectory /tmp
 
## Backup history?
Get-DbaBackupHistory -SqlInstance localhost:14331 -SqlCredential $cred | Out-GridView

#More Detail
Get-DbaBackupHistory -SqlInstance localhost:14331 -SqlCredential $cred  | select -First 1 | Select *


# Next, perform export (not currently supported on Core)
Export-DbaInstance -SqlInstance localhost:14331 -SqlCredential $cred -Exclude LinkedServers, Credentials, CentralManagementServer, BackupDevices
 
Export-DbaDatabase -SqlInstance localhost:14331 -SqlCredential $cred -OutputStyle NestedByDate -Database Northwind, pubs


#Powershell Core
Start-Process 'https://sqldbawithabeard.com/tag/powershell-core/'


## Are my alerts set up ?
$cred = Import-Clixml "C:\SQLSaturday\DemoCred.Cred"
Get-DbaAgentAlert -SqlInstance LensmanSB:14331 -SqlCredential $cred | Out-GridView

## Excellent - Perhaps I need a pester test for those for my default setup

Describe "Testing my Defaults" {
    Context "Alerts" {
        $cred = Import-Clixml "C:\SQLSaturday\DemoCred.Cred"
        $Instances = 'LensmanSB:14331'
        $testCases = @()
        $Instances.ForEach{$testCases += @{Instance = $_}}
        It "<Instance> Should have at least 12 Alerts" -TestCases $TestCases {
            param($Instance)
            (Get-DbaAgentAlert -SqlInstance $Instance -SqlCredential $cred).Count |Should BeGreaterThan 11 

        }
        $Alerts = 'custom alert', 'Error Number 823', 'Severity 016', 'Severity 017', 'Severity 018', 'Severity 019', 'Severity 020', 'Severity 021', 'Severity 022', 'Severity 023', 'Severity 024', 'Severity 025'
        foreach ($alert in $Alerts) {
            It "<Instance> Should have Alert - $Alert" -TestCases $TestCases {
                param($Instance)
                (Get-DbaAgentAlert -SqlInstance $Instance -SqlCredential $cred).Name.Contains($Alert) | Should Be $True
            }
        }
    }
}

# Maybe you want to look at execution plans
# C:\Users\mrrob\OneDrive\Documents\GitHub\Presentations\DBAReports Demo\DBA Reports Demo\DBA Reports Demo\01 - DBA Reports Demo.sql

Get-DbaExecutionPlan -SqlInstance lensmansb | Out-GridView

# DBCC Commands
Get-DbaDbccStatistic -SqlInstance LensmanSB -Database WideWorldImporters -Option DensityVector

Get-DbaDbccHelp -SqlInstance LensmanSB -Statement FREESYSTEMCACHE -Verbose | Format-List
Get-DbaDbccHelp -SqlInstance LensmanSB -Statement WritePage -IncludeUndocumented | Format-List