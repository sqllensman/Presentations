﻿# Setup a Linux Environment
docker pull dbatools/sqlinstance
docker pull dbatools/sqlinstance2

# create a shared network
docker network create localnet

# setup two containers and expose ports
docker run -p 14331:1433 -p 5022:5022 --network localnet --hostname dockersql1 --name dockersql1 -d dbatools/sqlinstance
docker run -p 14332:1433 -p 5023:5023  --network localnet --hostname dockersql2 --name dockersql2 -d dbatools/sqlinstance2

# Check running
docker ps -a


docker stop dockersql1 dockersql2
docker rm dockersql1 dockersql2