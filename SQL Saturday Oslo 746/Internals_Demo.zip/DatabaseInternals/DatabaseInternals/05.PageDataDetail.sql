USE [CheckDB]
GO


-- Basic Command
DBCC TRACEON(3604)
DBCC PAGE('Northwind', 1,472,1) WITH TABLERESULTS
DBCC PAGE('Northwind', 1,472,3) WITH TABLERESULTS
DBCC PAGE('Northwind', 1,472,2) WITH TABLERESULTS

Exec CheckDB.[dbo].[prc_ReadPageData] 'Northwind', 1,472


-- dbo.PageHeaderInfo
-- dbo.PageDataInfo
-- dbo.DBCC_Page_Records

DECLARE @RC int
DECLARE @DatabaseName nvarchar(128) = N'NorthWind'

EXECUTE @RC = [dbo].[Get_DatabasePageDataDetail] 
   @DatabaseName
GO


Select * from dbo.PageHeaderInfo
WHERE DatabaseName = 'NorthWind'
ORDER BY PageId

Select * from dbo.PageDataInfo
WHERE DatabaseName = 'NorthWind'
ORDER BY PageId

Select * from dbo.DBCC_Page_Records
WHERE DatabaseName = 'NorthWind'
AND PageId = 472
ORDER BY PageId, SlotNo


