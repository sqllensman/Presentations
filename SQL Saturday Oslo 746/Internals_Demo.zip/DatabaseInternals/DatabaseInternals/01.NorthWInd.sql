-- 01.Setup
-- Restore NorthWind
-- Restore PowerBIInternals
-- Restore CheckDB
-- Requires SQL Server 2017

Use master
GO

Alter Database NorthWind SET SINGLE_USER WITH ROLLBACK IMMEDIATE 

Restore Database NorthWind
FROM Disk = 'C:\Lensman\Presentations\OSLO\PowerBI Internals\Demo\Northwind.bak'
WITH STATS, CHECKSUM, REPLACE

-- Run Disk Usage Report



