/* Demo Instructions

1. Restore Copy of NorthWind - 01.NorthWInd.sql

2. Run the Disk Usage Report

3. View and Run 02.DatabaseInfo.sql

4. View SQLSatOsl01.bbix - DiskUsage

5. Page Data

	View and Run 03.PageData.sql
	View Code for [dbo].[Get_DatabasePageData] 

	View SQLSatOsl01.bbix - PageTypes
	Refresh Data

	View 04.SystemTables.sql

6. Page Data Detail
	View and Run 05.PageDataDetails

	View SQLSatOsl01.bbix - PageStructure & DataRecord
	Refresh Data

7. Index Records
	View and Run 05.IndexRecordData
