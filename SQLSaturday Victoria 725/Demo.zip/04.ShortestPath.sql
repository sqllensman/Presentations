-- Speakers at same event know each other
CREATE TABLE GraphData.[knows](
	[EventNum] smallint NOT NULL
)
AS EDGE;

With Speakers(Name, Node_Id) as
(
	Select Name, $node_id from GraphData.Speakers
), SpeakerNodes(EventNum, Name, Node_Id) as
(
	Select sj.EventNum, s.Name, s.Node_Id
	FROM Speakers s
	INNER JOIN
	(
		Select Distinct EventNum, Name
		FROM Event.Session
		WHERE EventNum in (Select [EventNum] FROM GraphData.SQLSaturdays)
	) sj
		On sj.Name = s.Name
)
INSERT INTO GraphData.[knows]($to_id,$from_id,EventNum)
SELECT S1.Node_Id as TO_ID, S2.Node_Id as FROM_ID, S1.EventNum 
FROM SpeakerNodes as S1
INNER JOIN SpeakerNodes as S2
	ON S1.EventNum = S2.EventNum
	AND S1.Name <> S2.Name
--WHERE S1.EventNum = 725

Select 
	Speaker1.Name, 
	Speaker2.Name, 
	Min(knows.EventNum) as EventNum,
	Count(*) as NoConnections
FROM GraphData.Speakers Speaker1, 
	 GraphData.knows knows, 
	 GraphData.Speakers Speaker2 
WHERE Match (Speaker1-(knows)-> Speaker2)
AND Speaker1.Name = 'Patrick Flynn'
GROUP BY Speaker1.Name, Speaker2.Name
ORDER BY EventNum


-- ===================== Graph Traversal EXAMPLE 1 =====================
-- First, we use a primitive / brute force approach by explictly checking for fixed-length
-- paths; first 1-hop, then 2-hop and so on. This approach does not check for cycles
-- and is limted by number of hops
DECLARE @OriginUser AS VARCHAR (256) = 'Patrick Flynn';

DECLARE @DestUser AS VARCHAR (256) = 'Buck Woody';
-- Fixed length paths
SELECT CONCAT(U1.Name, '->', U2.Name) AS FriendPath,
       1 AS PathLength
FROM   GraphData.Speakers AS U1, GraphData.Speakers AS U2, GraphData.knows AS F
WHERE  U1.Name = @OriginUser
       AND U2.Name = @DestUser
       AND MATCH(U1-(F)->U2)
UNION ALL
SELECT CONCAT(U1.Name, '->', U2.Name, '->', U3.Name) AS FriendPath,
       2 AS PathLength
FROM   GraphData.Speakers AS U1, GraphData.Speakers AS U2, GraphData.Speakers AS U3, GraphData.knows AS F1, GraphData.knows AS F2
WHERE  U1.Name = @OriginUser
       AND U3.Name = @DestUser
       AND MATCH(U1-(F1)->U2
                 AND U2-(F2)->U3)
UNION ALL
SELECT CONCAT(U1.Name, '->', U2.Name, '->', U3.Name, '->', U4.Name) AS FriendPath,
       3 AS PathLength
FROM   GraphData.Speakers AS U1, GraphData.Speakers AS U2, GraphData.Speakers AS U3, GraphData.Speakers AS U4, GraphData.knows AS F1, GraphData.knows AS F2, GraphData.knows AS F3
WHERE  U1.Name = @OriginUser
       AND U4.Name = @DestUser
       AND MATCH(U1-(F1)->U2
                 AND U2-(F2)->U3
                 AND U3-(F3)->U4)
UNION ALL
SELECT CONCAT(U1.Name, '->', U2.Name, '->', U3.Name, '->', U4.Name, '->', U5.Name) AS FriendPath,
       4 AS PathLength
FROM   GraphData.Speakers AS U1, GraphData.Speakers AS U2, GraphData.Speakers AS U3, GraphData.Speakers AS U4, GraphData.Speakers AS U5, GraphData.knows AS F1, GraphData.knows AS F2, GraphData.knows AS F3, GraphData.knows AS F4
WHERE  U1.Name = @OriginUser
       AND U5.Name = @DestUser
       AND MATCH(U1-(F1)->U2
                 AND U2-(F2)->U3
                 AND U3-(F3)->U4
                 AND U4-(F4)->U5);
GO
-- ===================== END Graph Traversal EXAMPLE 1 =====================

-- ===================== Graph Traversal EXAMPLE 2 =====================
-- Next, we use BFS to compute length and actual path for the shortest path
-- between two specific users
CREATE TABLE #t (
    Name VARCHAR (100)  UNIQUE CLUSTERED,
    level   INT           ,
    path    VARCHAR (8000)
);

CREATE INDEX il
    ON #t(level)
    INCLUDE(path);

DECLARE @OriginUser AS VARCHAR (256) = 'Patrick Flynn';
DECLARE @DestUser AS VARCHAR (256) = 'Buck Woody';
DECLARE @level AS INT = 0;

INSERT  #t
VALUES (@OriginUser, @level, @OriginUser);

WHILE @@rowcount > 0
      AND NOT EXISTS (SELECT *
                      FROM   #t
                      WHERE  Name = @DestUser)
    BEGIN
        SET @level += 1;
        INSERT #t
        SELECT Name,
               level,
               concat(path, ' -> ', Name)
        FROM   (SELECT   u2.Name,
                         @level AS level,
                         min(t1.path) AS path
                FROM     #t AS t1 WITH (FORCESEEK), GraphData.Speakers AS u1, GraphData.knows AS f, GraphData.Speakers AS u2
                WHERE    t1.level = @level - 1
                         AND t1.Name = u1.Name
                         AND MATCH(u1-(f)->u2)
                         AND NOT EXISTS (SELECT *
                                         FROM   #t AS t2 WITH (FORCESEEK)
                                         WHERE  t2.Name = u2.Name)
                GROUP BY u2.Name) AS q;
    END

SELECT *
FROM   #t
WHERE  Name = @DestUser;

DROP TABLE #t;
GO
-- ===================== END Graph Traversal EXAMPLE 2 =====================
-- ===================== Graph Traversal EXAMPLE 3 =====================
-- Next, compute single source shortest path (distance only)
-- This outputs shortest paths from the given start node to each of the nodes
-- which are reachable from this start node. Note again that this query only
-- lists the *distance* and not the actual path
CREATE TABLE #t (
    Name VARCHAR (100) UNIQUE CLUSTERED,
    level   INT           INDEX il NONCLUSTERED
);

DECLARE @OriginUser AS VARCHAR (256) = 'Chris Wood';

DECLARE @level AS INT = 0;

INSERT  #t
VALUES (@OriginUser, @level);

WHILE @@rowcount > 0
    BEGIN
        SET @level += 1;
        INSERT #t
        SELECT DISTINCT u2.Name,
                        @level
        FROM   #t AS t1 WITH (FORCESEEK), GraphData.Speakers AS u1, GraphData.knows AS f, GraphData.Speakers AS u2
        WHERE  t1.level = @level - 1
               AND t1.Name = u1.Name
               AND MATCH(u1-(f)->u2)
               AND NOT EXISTS (SELECT *
                               FROM   #t AS t2 WITH (FORCESEEK)
                               WHERE  t2.Name = u2.Name);
    END

SELECT * FROM   #t;
SELECT @OriginUser, Avg(level*1.0), Max(level)
FROM #t

DROP TABLE #t;
GO
-- ===================== END Graph Traversal EXAMPLE 3 =====================

-- ===================== Graph Traversal EXAMPLE 4 =====================
-- Finally, compute single source shortest path (with full path) to all other nodes
-- This takes a bit longer than Example 3 above for obvious reasons
CREATE TABLE #t (
    Name VARCHAR (256)  UNIQUE CLUSTERED,
    level   INT           ,
    path    VARCHAR (8000)
);

CREATE INDEX il
    ON #t(level)
    INCLUDE(path);

DECLARE @OriginUser AS VARCHAR (256) = 'Kevin Boles';

DECLARE @level AS INT = 0;

INSERT  #t
VALUES (@OriginUser, @level, @OriginUser);

WHILE @@rowcount > 0
    BEGIN
        SET @level += 1;
        INSERT #t
        SELECT Name,
               level,
               concat(path, ' -> ', Name)
        FROM   (SELECT   u2.Name,
                         @level AS level,
                         min(t1.path) AS path
                FROM     #t AS t1 WITH (FORCESEEK), GraphData.Speakers AS u1, GraphData.knows AS f, GraphData.Speakers AS u2
                WHERE    t1.level = @level - 1
                         AND t1.Name = u1.Name
                         AND MATCH(u1-(f)->u2)
                         AND NOT EXISTS (SELECT *
                                         FROM   #t AS t2 WITH (FORCESEEK)
                                         WHERE  t2.Name = u2.Name)
                GROUP BY u2.Name) AS q;
    END

Select @OriginUser as Name, 
	Max(Level) as LongestPathLen,
	Avg(Level*1.0) as AveragePathLength
FROM #t

SELECT Name, Level, Path FROM   #t;

DROP TABLE #t;
GO
-- ===================== END Graph Traversal EXAMPLE 4 =====================
