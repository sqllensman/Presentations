DECLARE @Speaker as VARCHAR(256);
DECLARE @SpeakerCursor as CURSOR;
 
TRUNCATE TABLE [dbo].[Speaker_DOS]

SET @SpeakerCursor = CURSOR FAST_FORWARD FOR
SELECT Name from GraphData.Speakers

OPEN @SpeakerCursor;
FETCH NEXT FROM @SpeakerCursor INTO @Speaker;

WHILE @@FETCH_STATUS = 0
BEGIN
	
	INSERT INTO [dbo].[Speaker_DOS] EXECUTE [dbo].[get_Speaker_DS] @OriginUser = @Speaker;
    FETCH NEXT FROM @SpeakerCursor INTO @Speaker;
END
CLOSE @SpeakerCursor;
DEALLOCATE @SpeakerCursor;

/*
Select Count(*) as NoEvents, Name
FROM
(
	Select Distinct [EventNum], Trim([Name]) as Name
	FROM Event.Session
) s
Group By Name
Order By NoEvents Desc
*/

Select * from [dbo].[Speaker_DOS] 
WHERE TotalConnections > 100
order by AveragePathLen

Select * from [dbo].[Speaker_DOS] 
WHERE (Speaker in (Select name from Event.Session WHERE EventNum =725))
order by AveragePathLen
