Use [6Degrees]
GO

create schema GraphData
go

CREATE TABLE [GraphData].[SQLSaturdays](
	[EventNum] [smallint] NOT NULL,
	[EventName] [varchar](50) NULL,
	[EventDate] [date] NULL,
	[Country] [varchar](128) NULL,
 CONSTRAINT [PK_SQLSaturdays] PRIMARY KEY CLUSTERED 
(
	[EventNum] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
)
AS NODE ON [PRIMARY]
GO

CREATE TABLE [GraphData].[Speakers](
	[Name] varchar(256) NOT NULL,
 CONSTRAINT [PK_Speakers] PRIMARY KEY CLUSTERED 
(
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
)
AS NODE ON [PRIMARY]
GO

CREATE TABLE [GraphData].[Session](
	[EventNum] [smallint] NOT NULL,
	[SessionName] nvarchar(128) NOT NULL,
 CONSTRAINT [PK_Session] PRIMARY KEY CLUSTERED 
(
	[EventNum] ASC,
	[SessionName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
)
AS NODE ON [PRIMARY]
GO

CREATE TABLE [GraphData].[Attendee](
	[EventNum] [smallint] NOT NULL,
	[Name] varchar(256) NOT NULL,
 CONSTRAINT [PK_Attendees] PRIMARY KEY CLUSTERED 
(
	[EventNum] ASC,
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
)
AS NODE ON [PRIMARY]
GO

-- Insert Events (only completed events including today)
INSERT INTO GraphData.SQLSaturdays([EventNum], [EventName], [EventDate], [Country])
SELECT [EventNum], [EventName], [EventDate], [Country]
FROM Event.Events
WHERE NameId = 1
AND Status = 1
AND EventDate <= '2018-03-03';



-- Insert Speakers
INSERT INTO GraphData.Speakers(Name)
Select Distinct Name
FROM Event.Session
WHERE EventNum in (Select [EventNum] FROM GraphData.SQLSaturdays)

INSERT INTO GraphData.Session(EventNum, SessionName) 
SELECT [EventNum], [Title]
FROM Event.Session
WHERE EventNum in (Select [EventNum] FROM GraphData.SQLSaturdays)


-- Insert a generic attendee
INSERT GraphData.Attendee(EventNum, Name)
SELECT [EventNum], 'SQL Saturday ' + Cast(EventNum as varchar(10)) + ' attendee' as Name 
FROM Event.Events
WHERE NameId = 1
AND Status = 1
AND EventDate <= '2018-03-03';


-- Edge Tables
-- Speaker presents at Event
CREATE TABLE GraphData.[PresentedAt](
	[Rating] decimal(10,2) NOT NULL
)
AS EDGE

-- Session Presented By Speaker
CREATE TABLE GraphData.[PresentedBy]
AS EDGE

-- Session Delivered at Event
CREATE TABLE GraphData.[DeliveredAt](
	[Rating] decimal(10,2) NOT NULL,
	[Attendees] smallint
)
AS EDGE

-- Attendees attend an Event
CREATE TABLE GraphData.[Attended](
	[Rating] decimal(10,2) NOT NULL
)
AS EDGE



---------------------------------------------------------------------------
                                                                 

-- Populate the PresentedBy edge
With Speakers(Name, To_Id) as
(
	Select Name, $node_id from GraphData.Speakers
), Sessions(SessionName, EventNum, From_Id) as
(
	select SessionName, EventNum, $node_id from GraphData.Session
)
INSERT INTO GraphData.PresentedBy($to_id,$from_id)
Select To_Id, From_Id
FROM Speakers s
INNER JOIN
(
	Select EventNum, Name, Title 
	FROM Event.Session
	WHERE EventNum in (Select [EventNum] FROM GraphData.SQLSaturdays)
) sj
	On sj.Name = s.Name
INNER JOIN Sessions ses
	ON ses.EventNum = sj.EventNum
	AND ses.SessionName  = sj.Title

-- Populate DeliveredAt Edge
With SQLSaturdays(EventNum, To_Id) as
(
	select EventNum, $node_id from GraphData.SQLSaturdays
), Sessions(SessionName, EventNum, From_Id) as
(
	select SessionName, EventNum, $node_id from GraphData.Session
)
INSERT INTO GraphData.DeliveredAt($to_id,$from_id, Rating, Attendees)
Select To_Id, From_Id, 5, Round(Rand() * 150, 0)
FROM SQLSaturdays s
INNER JOIN Sessions ses
	ON ses.EventNum = s.EventNum

-- Populate the Attended edge
With SQLSaturdays(EventNum, To_Id) as
(
	select EventNum, $node_id from GraphData.SQLSaturdays
), Attendee(Name, EventNum, From_Id) as
(
	select Name, EventNum, $node_id from [GraphData].[Attendee]
)
INSERT INTO GraphData.Attended($to_id,$from_id, Rating)
Select To_Id, From_Id, 5
FROM SQLSaturdays s
INNER JOIN Attendee a
	ON a.EventNum = s.EventNum