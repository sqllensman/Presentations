-- Data from SQL Saturday Events
Use [6Degrees]
GO

-- Raw Data
Select * from dbo.GuidebookXML
WHERE ID = 725

-- Events by Countr
SELECT [Country], Count(*) as NoEvents
FROM [6Degrees].[Event].[Events]
group by Country
order by NoEvents Desc, Country

-- Events
Select * From Event.Events
WHERE EventNum = 725

-- Sessions
Select * From Event.Session
WHERE EventNum = 725

-- Sessions Per Event
Select EventNum, Count(*) AS NoSessions
FROM Event.Session
Group By EventNum
Order bY NoSessions Desc

-- Speakers
Select Distinct Trim([Name]) as Name
FROM Event.Session
Order by Name

-- No of Sessions
Select Name, Count(*) as NoSessions
FROM [Event].[Session]
GROUP BY Name
ORDER BY Name

