-- Get List of Speakers Presenting at a SQL Saturday
Select 
	Speakers.Name, 
	SQLSaturday.EventName, 
	SQLSaturday.EventDate, 
	SQLSaturday.Country
FROM GraphData.Speakers Speakers, 
	 GraphData.PresentedAt, 
	 GraphData.SQLSaturdays SQLSaturday
WHERE Match (Speakers-(PresentedAt)-> SQLSaturday)
AND SQLSaturday.EventNum = 725
ORDER BY Speakers.Name

-- Can use Agregates etc
Select 
	Count(*) as NoSpeakers, 
	SQLSaturday.EventNum, 
	SQLSaturday.EventDate
FROM GraphData.Speakers Speakers, 
	 GraphData.PresentedAt, 
	 GraphData.SQLSaturdays SQLSaturday
WHERE Match (Speakers-(PresentedAt)-> SQLSaturday)
GROUP BY SQLSaturday.EventNum, SQLSaturday.EventDate
ORDER BY NoSpeakers Desc

-- Look at Sessions Presented
Select Speakers.Name, Session.EventNum, Session.SessionName
FROM GraphData.Speakers Speakers, 
	 GraphData.PresentedBy as PresentedBy,
	 GraphData.Session as Session
WHERE Match (Session-(PresentedBy)->Speakers)
AND Speakers.Name = 'Patrick Flynn'

--
Select Speakers.Name, Session.EventNum, Session.SessionName, SQLSaturdays.EventDate, DeliveredAt.Attendees
FROM GraphData.Speakers as Speakers, 
	 GraphData.PresentedBy as PresentedBy,
	 GraphData.Session as Session,
	 GraphData.DeliveredAt as DeliveredAt,
	 GraphData.SQLSaturdays as SQLSaturdays
WHERE Match (SQLSaturdays<-(DeliveredAt)-Session-(PresentedBy)-> Speakers)
AND Speakers.Name = 'Patrick Flynn'

-- Can be done by Joining to SQLSaturdays but lose information from edge table 
Select Speakers.Name, Session.EventNum, Session.SessionName, SQLSaturdays.EventDate
FROM GraphData.Speakers as Speakers, 
	 GraphData.PresentedBy as PresentedBy,
	 GraphData.Session as Session,
	 GraphData.SQLSaturdays as SQLSaturdays
WHERE Match (Session-(PresentedBy)-> Speakers)
AND Session.EventNum = SQLSaturdays.EventNum
AND Speakers.Name = 'Patrick Flynn'


-- Look at from an Attendee

-- All events in Canada
Select SQLSaturdays.EventNum, SQLSaturdays.EventName, SQLSaturdays.EventDate, Attendee.Name, Attended.Rating
from GraphData.Attendee,
	 GraphData.Attended,
	 GraphData.SQLSaturdays
WHERE Match (Attendee-(Attended)->SQLSaturdays)
AND SQLSaturdays.Country = 'Canada'

-- All Speakers from any event in Canada
Select SQLSaturdays.EventNum, SQLSaturdays.EventName, SQLSaturdays.EventDate, Attendee.Name, Attended.Rating, Speakers.Name as Speaker
from GraphData.Attendee,
	 GraphData.Attended,
	 GraphData.SQLSaturdays, 
	 GraphData.Speakers Speakers, 
	 GraphData.PresentedAt
WHERE Match (Attendee-(Attended)->SQLSaturdays<-(PresentedAt)-Speakers)
AND SQLSaturdays.Country = 'Canada'


-- All Speakers at this event 
-- Who are you directly connected to ?
Select SQLSaturdays.EventNum, SQLSaturdays.EventName, SQLSaturdays.EventDate, Attendee.Name, Attended.Rating, Speakers.Name as Speaker
from GraphData.Attendee,
	 GraphData.Attended,
	 GraphData.SQLSaturdays, 
	 GraphData.Speakers Speakers, 
	 GraphData.PresentedAt
WHERE Match (Attendee-(Attended)->SQLSaturdays<-(PresentedAt)-Speakers)
AND SQLSaturdays.EventNum = '725'

-- Find Other Events that Speakers have presented at
Select 
	Speakers.Name, 
	OtherEvent.EventNum,
	OtherEvent.EventName,
	OtherEvent.EventDate,
	OtherEvent.Country
FROM	
	GraphData.Speakers, 
	GraphData.PresentedAt, 
	GraphData.SQLSaturdays SQLSatVictoria,
	GraphData.PresentedAt as AlsoPresented,
	GraphData.SQLSaturdays as OtherEvent
WHERE Match (Speakers-(PresentedAt)-> SQLSatVictoria )
AND Match (Speakers-(AlsoPresented)-> OtherEvent )
AND SQLSatVictoria.EventNum = 725
--AND OtherEvent.EventNum = 521
ORDER BY Speakers.Name, OtherEvent.EventDate Desc


