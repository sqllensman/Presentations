-- Data from SQL Saturday Events
Use [6Degrees]
GO

-- Drop Edge Tables
DROP TABLE [GraphData].[Attended]
DROP TABLE [GraphData].[DeliveredAt]
DROP TABLE [GraphData].[knows]
DROP TABLE [GraphData].[PresentedAt]
DROP TABLE [GraphData].[PresentedBy]
GO

-- Drop Node Tables
DROP TABLE [GraphData].[Attendee]
DROP TABLE [GraphData].[Session]
DROP TABLE [GraphData].[Speakers]
DROP TABLE [GraphData].[SQLSaturdays]
GO


-- Drop Schema
DROP SCHEMA [GraphData]
GO




