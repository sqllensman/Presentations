
Declare @StartingEvent smallint = 725
Declare @Level smallint = 0
Declare @Complete Bit = 0 

CREATE TABLE #Event_DOS(
	[EventNum] [smallint] NOT NULL,
	[DOS] [smallint] NOT NULL
)

INSERT INTO #Event_DOS([EventNum], [DOS])
Select @StartingEvent, @Level

WHILE @Complete = 0
BEGIN
	Set @Level = @Level+ 1;

	INSERT INTO #Event_DOS([EventNum], [DOS])
	Select EventNum, @Level
	FROM
	(
		Select Distinct OtherEvent.EventNum
		FROM 
			GraphData.Speakers, 
			GraphData.PresentedAt, 
			GraphData.SQLSaturdays SQLSatVictoria,
			GraphData.PresentedAt as AlsoPresented,
			GraphData.SQLSaturdays as OtherEvent
		WHERE Match (Speakers-(PresentedAt)-> SQLSatVictoria )
		AND Match (Speakers-(AlsoPresented)-> OtherEvent )
		AND SQLSatVictoria.EventNum IN (Select EventNum from #Event_DOS)
		EXCEPT
		Select EventNum from #Event_DOS
	) a

	If @@RowCount = 0
	BEGIN
			INSERT INTO #Event_DOS([EventNum], [DOS])
			Select EventNum, -1
			FROM
			(
				SELECT EventNum from [GraphData].[SQLSaturdays]
				EXCEPT
				Select EventNum from #Event_DOS
			) a;

			SET @Complete = 1
	END
END

Select *
from #Event_DOS

Select 
	@StartingEvent as Starting, 
	MAX(DOS) as Largest_Gap, 
	AVG(DOS*1.0) as Average_Gap
from #Event_DOS

DROP TABLE #Event_DOS




